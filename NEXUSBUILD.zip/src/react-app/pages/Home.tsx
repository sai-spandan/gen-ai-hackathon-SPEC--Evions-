import { Button } from "@/react-app/components/ui/button";
import { ArrowRight, Sparkles, BrainCircuit, Calendar, IndianRupee, AlertTriangle, Cpu, Target, Users, Building2, GraduationCap, Zap, FileText, Calculator, BookOpen } from "lucide-react";
import { FeatureCard } from "@/react-app/components/FeatureCard";
import { ProjectDashboard } from "@/react-app/components/ProjectDashboard";
import { ProjectGenerator } from "@/react-app/components/ProjectGenerator";
import { Footer } from "@/react-app/components/Footer";
import { AnimatedCounter } from "@/react-app/components/AnimatedCounter";
import { CostCalculator } from "@/react-app/components/CostCalculator";
import { ProjectComparison } from "@/react-app/components/ProjectComparison";

export default function Home() {
  const scrollToGenerator = () => {
    document.getElementById('generator')?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToFeatures = () => {
    document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Animated Background Grid */}
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0" style={{
            backgroundImage: `linear-gradient(to right, hsl(var(--primary)) 1px, transparent 1px),
                            linear-gradient(to bottom, hsl(var(--primary)) 1px, transparent 1px)`,
            backgroundSize: '40px 40px'
          }} />
        </div>

        {/* Glowing Orbs */}
        <div className="absolute top-20 left-20 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-pulse delay-1000" />

        {/* Hero Content */}
        <div className="relative z-10 max-w-6xl mx-auto px-6 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-8">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">AI-Powered Construction Planning</span>
          </div>

          <h1 className="text-6xl md:text-7xl lg:text-8xl font-black mb-6 leading-tight">
            Build Smarter.{" "}
            <span className="text-primary">Plan Faster.</span>{" "}
            <br />Execute Better.
          </h1>

          <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto mb-12">
            AI-powered construction planning, timelines, and cost estimation in one platform.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              size="lg" 
              className="text-lg px-8 py-6 glow-orange transition-all hover:glow-orange-strong group"
              onClick={scrollToGenerator}
            >
              Generate Project Plan
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="text-lg px-8 py-6 border-primary/30 hover:bg-primary/10"
              onClick={scrollToFeatures}
            >
              View Features
            </Button>
          </div>

          {/* Floating Elements */}
          <div className="mt-20 grid grid-cols-3 gap-4 max-w-2xl mx-auto opacity-50">
            <div className="h-20 rounded-lg border border-primary/20 bg-primary/5 backdrop-blur-sm animate-float" style={{ animationDelay: '0s' }} />
            <div className="h-20 rounded-lg border border-primary/20 bg-primary/5 backdrop-blur-sm animate-float" style={{ animationDelay: '0.2s' }} />
            <div className="h-20 rounded-lg border border-primary/20 bg-primary/5 backdrop-blur-sm animate-float" style={{ animationDelay: '0.4s' }} />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">Powerful Features</span>
            </div>
            
            <h2 className="text-4xl md:text-5xl font-black mb-4">
              Everything You Need to{" "}
              <span className="text-primary">Build Better</span>
            </h2>
            
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Comprehensive tools designed for modern construction planning
            </p>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <FeatureCard
              icon={BrainCircuit}
              title="Smart Project Planning"
              description="Automated phase-wise construction plans that adapt to your project needs and timeline requirements."
            />
            
            <FeatureCard
              icon={Calendar}
              title="Timeline & Date Management"
              description="Accurate schedules without date offset issues. Keep your project on track with intelligent scheduling."
            />
            
            <FeatureCard
              icon={IndianRupee}
              title="Cost Estimation (₹ INR)"
              description="India-based budgeting and breakdown with detailed cost analysis for every phase of construction."
            />
            
            <FeatureCard
              icon={AlertTriangle}
              title="Risk Identification"
              description="Proactively highlights potential delays and construction risks before they impact your timeline."
            />
            
            <FeatureCard
              icon={Cpu}
              title="AI-Ready System"
              description="Scalable architecture built for future AI upgrades and intelligent automation capabilities."
            />
            
            <FeatureCard
              icon={Sparkles}
              title="Intelligent Insights"
              description="Data-driven recommendations to optimize your construction process and maximize efficiency."
            />
          </div>
        </div>
      </section>

      {/* Project Dashboard Section */}
      <section id="dashboard" className="py-24 px-6 bg-card/50">
        <div className="max-w-5xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">Live Dashboard</span>
            </div>
            
            <h2 className="text-4xl md:text-5xl font-black mb-4">
              Your Project at a{" "}
              <span className="text-primary">Glance</span>
            </h2>
            
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Real-time insights into timeline, costs, and risks
            </p>
          </div>

          {/* Dashboard */}
          <ProjectDashboard />
        </div>
      </section>

      {/* Interactive Tools Section */}
      <section className="py-24 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">Interactive Tools</span>
            </div>
            
            <h2 className="text-4xl md:text-5xl font-black mb-4">
              Smart Planning{" "}
              <span className="text-primary">Tools</span>
            </h2>
            
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Explore costs and compare options in real-time
            </p>
          </div>

          {/* Tools Grid */}
          <div className="grid lg:grid-cols-2 gap-8 mb-8">
            <CostCalculator />
            <ProjectComparison />
          </div>
        </div>
      </section>

      {/* Project Generator Section */}
      <section id="generator" className="py-24 px-6 bg-card/50">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">AI-Powered Generator</span>
            </div>
            
            <h2 className="text-4xl md:text-5xl font-black mb-4">
              Create Your{" "}
              <span className="text-primary">Project Plan</span>
            </h2>
            
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Generate comprehensive construction plans in seconds
            </p>
          </div>

          {/* Generator Form */}
          <ProjectGenerator />
        </div>
      </section>

      {/* About Section */}
      <section className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Text Content */}
            <div>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
                <Target className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium text-primary">About Nexus Build</span>
              </div>
              
              <h2 className="text-4xl md:text-5xl font-black mb-6">
                Building the Future of{" "}
                <span className="text-primary">Construction Tech</span>
              </h2>
              
              <div className="space-y-6 text-muted-foreground">
                <div>
                  <h3 className="text-xl font-bold text-foreground mb-2">Our Mission</h3>
                  <p className="text-lg">
                    Simplify construction planning through intelligent automation, making professional-grade project management accessible to everyone.
                  </p>
                </div>
                
                <div>
                  <h3 className="text-xl font-bold text-foreground mb-2">Our Vision</h3>
                  <p className="text-lg">
                    Become the digital backbone of the construction industry, empowering builders with data-driven insights and AI-powered tools.
                  </p>
                </div>
                
                <div>
                  <h3 className="text-xl font-bold text-foreground mb-2">The Problem We Solve</h3>
                  <p className="text-lg">
                    Construction projects often face delays, budget overruns, and planning inefficiencies. Nexus Build provides intelligent automation to eliminate these challenges before they impact your project.
                  </p>
                </div>
              </div>
            </div>

            {/* Visual Elements */}
            <div className="relative">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-4">
                  <div className="h-40 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 border border-primary/20 backdrop-blur-sm flex items-center justify-center hover:scale-105 transition-transform">
                    <div className="text-center">
                      <div className="text-4xl font-black text-primary mb-1">
                        <AnimatedCounter end={10} suffix="K+" />
                      </div>
                      <div className="text-sm text-muted-foreground">Projects Planned</div>
                    </div>
                  </div>
                  <div className="h-32 rounded-2xl bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20 backdrop-blur-sm flex items-center justify-center hover:scale-105 transition-transform">
                    <div className="text-center">
                      <div className="text-3xl font-black text-primary mb-1">
                        <AnimatedCounter end={98} suffix="%" />
                      </div>
                      <div className="text-xs text-muted-foreground">Accuracy</div>
                    </div>
                  </div>
                </div>
                <div className="space-y-4 mt-8">
                  <div className="h-32 rounded-2xl bg-gradient-to-br from-primary/15 to-primary/5 border border-primary/20 backdrop-blur-sm flex items-center justify-center hover:scale-105 transition-transform">
                    <div className="text-center">
                      <div className="text-3xl font-black text-primary mb-1">
                        <AnimatedCounter end={50} suffix="%" />
                      </div>
                      <div className="text-xs text-muted-foreground">Time Saved</div>
                    </div>
                  </div>
                  <div className="h-40 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 border border-primary/20 backdrop-blur-sm flex items-center justify-center hover:scale-105 transition-transform">
                    <div className="text-center">
                      <div className="text-4xl font-black text-primary mb-1">24/7</div>
                      <div className="text-sm text-muted-foreground">AI Support</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Use Cases Section */}
      <section className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <Users className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">Who We Serve</span>
            </div>
            
            <h2 className="text-4xl md:text-5xl font-black mb-4">
              Built for{" "}
              <span className="text-primary">Everyone</span>
            </h2>
            
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              From individual home builders to large-scale developers
            </p>
          </div>

          {/* Use Cases Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="group p-6 rounded-2xl border border-primary/20 bg-card hover:border-primary/40 transition-all hover:scale-105">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                <Building2 className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Home Builders</h3>
              <p className="text-muted-foreground text-sm">
                Plan your dream home with accurate timelines and budgets
              </p>
            </div>

            <div className="group p-6 rounded-2xl border border-primary/20 bg-card hover:border-primary/40 transition-all hover:scale-105">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                <Users className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Contractors</h3>
              <p className="text-muted-foreground text-sm">
                Streamline project management and client communication
              </p>
            </div>

            <div className="group p-6 rounded-2xl border border-primary/20 bg-card hover:border-primary/40 transition-all hover:scale-105">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                <Target className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Real Estate Developers</h3>
              <p className="text-muted-foreground text-sm">
                Manage multiple projects with enterprise-grade planning
              </p>
            </div>

            <div className="group p-6 rounded-2xl border border-primary/20 bg-card hover:border-primary/40 transition-all hover:scale-105">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                <GraduationCap className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-2">Students & Hackathons</h3>
              <p className="text-muted-foreground text-sm">
                Learn construction planning with cutting-edge tools
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Future Roadmap Section */}
      <section className="py-24 px-6 bg-card/50">
        <div className="max-w-4xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <Zap className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">Coming Soon</span>
            </div>
            
            <h2 className="text-4xl md:text-5xl font-black mb-4">
              Future{" "}
              <span className="text-primary">Roadmap</span>
            </h2>
            
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Exciting features on the horizon
            </p>
          </div>

          {/* Roadmap Timeline */}
          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-primary/20" />

            {/* Roadmap Items */}
            <div className="space-y-8">
              <div className="relative pl-16">
                <div className="absolute left-0 w-12 h-12 rounded-full bg-primary/20 border-4 border-primary flex items-center justify-center">
                  <Zap className="w-5 h-5 text-primary" />
                </div>
                <div className="p-6 rounded-2xl border border-primary/20 bg-card hover:border-primary/30 transition-colors">
                  <h3 className="text-xl font-bold mb-2">AI Cost Optimization</h3>
                  <p className="text-muted-foreground">
                    Intelligent suggestions to reduce costs while maintaining quality
                  </p>
                </div>
              </div>

              <div className="relative pl-16">
                <div className="absolute left-0 w-12 h-12 rounded-full bg-primary/10 border-4 border-primary/30 flex items-center justify-center">
                  <Calculator className="w-5 h-5 text-primary/70" />
                </div>
                <div className="p-6 rounded-2xl border border-primary/20 bg-card hover:border-primary/30 transition-colors">
                  <h3 className="text-xl font-bold mb-2">GST Calculation</h3>
                  <p className="text-muted-foreground">
                    Automatic tax calculations integrated into cost estimates
                  </p>
                </div>
              </div>

              <div className="relative pl-16">
                <div className="absolute left-0 w-12 h-12 rounded-full bg-primary/10 border-4 border-primary/30 flex items-center justify-center">
                  <Building2 className="w-5 h-5 text-primary/70" />
                </div>
                <div className="p-6 rounded-2xl border border-primary/20 bg-card hover:border-primary/30 transition-colors">
                  <h3 className="text-xl font-bold mb-2">Material-wise Cost Estimates</h3>
                  <p className="text-muted-foreground">
                    Detailed breakdown of material costs with supplier recommendations
                  </p>
                </div>
              </div>

              <div className="relative pl-16">
                <div className="absolute left-0 w-12 h-12 rounded-full bg-primary/10 border-4 border-primary/30 flex items-center justify-center">
                  <FileText className="w-5 h-5 text-primary/70" />
                </div>
                <div className="p-6 rounded-2xl border border-primary/20 bg-card hover:border-primary/30 transition-colors">
                  <h3 className="text-xl font-bold mb-2">PDF Project Reports</h3>
                  <p className="text-muted-foreground">
                    Export professional reports for clients and stakeholders
                  </p>
                </div>
              </div>

              <div className="relative pl-16">
                <div className="absolute left-0 w-12 h-12 rounded-full bg-primary/10 border-4 border-primary/30 flex items-center justify-center">
                  <BookOpen className="w-5 h-5 text-primary/70" />
                </div>
                <div className="p-6 rounded-2xl border border-primary/20 bg-card hover:border-primary/30 transition-colors">
                  <h3 className="text-xl font-bold mb-2">Saved Projects & User Accounts</h3>
                  <p className="text-muted-foreground">
                    Store and manage multiple projects with team collaboration
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <Footer />
    </div>
  );
}
