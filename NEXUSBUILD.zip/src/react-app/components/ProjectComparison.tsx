import { useState } from "react";
import { Card } from "@/react-app/components/ui/card";
import { Button } from "@/react-app/components/ui/button";
import { GitCompare, Check, X, Zap } from "lucide-react";

interface ComparisonOption {
  name: string;
  duration: string;
  cost: string;
  features: { label: string; included: boolean }[];
  recommended?: boolean;
}

export function ProjectComparison() {
  const [selectedType, setSelectedType] = useState<string>("residential");

  const comparisonData: Record<string, ComparisonOption[]> = {
    residential: [
      {
        name: "Basic Build",
        duration: "4-6 months",
        cost: "₹15-25L",
        features: [
          { label: "Standard materials", included: true },
          { label: "Basic finishes", included: true },
          { label: "Premium finishes", included: false },
          { label: "Smart home features", included: false },
        ],
      },
      {
        name: "Premium Build",
        duration: "6-8 months",
        cost: "₹30-50L",
        recommended: true,
        features: [
          { label: "Standard materials", included: true },
          { label: "Basic finishes", included: true },
          { label: "Premium finishes", included: true },
          { label: "Smart home features", included: false },
        ],
      },
      {
        name: "Luxury Build",
        duration: "8-12 months",
        cost: "₹60L+",
        features: [
          { label: "Standard materials", included: true },
          { label: "Basic finishes", included: true },
          { label: "Premium finishes", included: true },
          { label: "Smart home features", included: true },
        ],
      },
    ],
    commercial: [
      {
        name: "Small Office",
        duration: "3-5 months",
        cost: "₹20-35L",
        features: [
          { label: "Basic infrastructure", included: true },
          { label: "HVAC system", included: true },
          { label: "Advanced security", included: false },
          { label: "Automation", included: false },
        ],
      },
      {
        name: "Corporate Space",
        duration: "6-9 months",
        cost: "₹50-80L",
        recommended: true,
        features: [
          { label: "Basic infrastructure", included: true },
          { label: "HVAC system", included: true },
          { label: "Advanced security", included: true },
          { label: "Automation", included: false },
        ],
      },
      {
        name: "Premium Complex",
        duration: "10-15 months",
        cost: "₹1Cr+",
        features: [
          { label: "Basic infrastructure", included: true },
          { label: "HVAC system", included: true },
          { label: "Advanced security", included: true },
          { label: "Automation", included: true },
        ],
      },
    ],
  };

  const options = comparisonData[selectedType];

  return (
    <Card className="p-8 border-primary/20 bg-gradient-to-br from-card to-card/50 backdrop-blur-sm relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute -top-20 -left-20 w-60 h-60 bg-primary/10 rounded-full blur-3xl" />
      <div className="absolute -bottom-20 -right-20 w-60 h-60 bg-primary/5 rounded-full blur-3xl" />

      <div className="relative z-10">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center">
            <GitCompare className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h3 className="text-2xl font-bold">Project Comparison</h3>
            <p className="text-sm text-muted-foreground">Compare different project types</p>
          </div>
        </div>

        {/* Type Selector */}
        <div className="flex gap-3 mb-8">
          <Button
            variant={selectedType === "residential" ? "default" : "outline"}
            onClick={() => setSelectedType("residential")}
            className="flex-1"
          >
            Residential
          </Button>
          <Button
            variant={selectedType === "commercial" ? "default" : "outline"}
            onClick={() => setSelectedType("commercial")}
            className="flex-1"
          >
            Commercial
          </Button>
        </div>

        {/* Comparison Grid */}
        <div className="grid md:grid-cols-3 gap-4">
          {options.map((option, index) => (
            <div
              key={index}
              className={`p-6 rounded-2xl border-2 transition-all hover:scale-105 ${
                option.recommended
                  ? "border-primary bg-primary/5 shadow-lg shadow-primary/20"
                  : "border-primary/20 bg-card hover:border-primary/30"
              }`}
            >
              {option.recommended && (
                <div className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-primary text-primary-foreground text-xs font-bold mb-3">
                  <Zap className="w-3 h-3" />
                  Recommended
                </div>
              )}

              <h4 className="text-xl font-black mb-2">{option.name}</h4>

              <div className="space-y-2 mb-6">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Duration:</span>
                  <span className="font-bold text-foreground">{option.duration}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Est. Cost:</span>
                  <span className="font-bold text-primary">{option.cost}</span>
                </div>
              </div>

              <div className="space-y-3 pt-4 border-t border-primary/20">
                {option.features.map((feature, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-sm">
                    {feature.included ? (
                      <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                    ) : (
                      <X className="w-4 h-4 text-muted-foreground/30 flex-shrink-0" />
                    )}
                    <span className={feature.included ? "text-foreground" : "text-muted-foreground/50"}>
                      {feature.label}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
}
