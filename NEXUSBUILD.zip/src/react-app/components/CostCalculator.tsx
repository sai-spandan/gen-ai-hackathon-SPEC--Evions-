import { useState } from "react";
import { Card } from "@/react-app/components/ui/card";
import { Slider } from "@/react-app/components/ui/slider";
import { Calculator, DollarSign, Zap } from "lucide-react";

export function CostCalculator() {
  const [area, setArea] = useState(1500);
  const [quality, setQuality] = useState(2); // 1: Basic, 2: Standard, 3: Premium

  const baseRatePerSqFt = quality === 1 ? 1200 : quality === 2 ? 1800 : 2500;
  const totalCost = area * baseRatePerSqFt;
  const materialCost = totalCost * 0.45;
  const laborCost = totalCost * 0.25;
  const otherCost = totalCost * 0.30;

  const qualityLabels = ["Basic", "Standard", "Premium"];

  return (
    <Card className="p-8 border-primary/20 bg-gradient-to-br from-card to-card/50 backdrop-blur-sm relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute -top-20 -right-20 w-40 h-40 bg-primary/20 rounded-full blur-3xl" />
      <div className="absolute -bottom-20 -left-20 w-40 h-40 bg-primary/10 rounded-full blur-3xl" />

      <div className="relative z-10">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center">
            <Calculator className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h3 className="text-2xl font-bold">Live Cost Calculator</h3>
            <p className="text-sm text-muted-foreground">Instant project cost estimates</p>
          </div>
        </div>

        {/* Area Slider */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-3">
            <label className="text-sm font-medium text-foreground">Construction Area</label>
            <span className="text-2xl font-black text-primary">{area} sq ft</span>
          </div>
          <Slider
            value={[area]}
            onValueChange={(values) => setArea(values[0])}
            min={500}
            max={5000}
            step={100}
            className="cursor-pointer"
          />
          <div className="flex justify-between text-xs text-muted-foreground mt-2">
            <span>500 sq ft</span>
            <span>5,000 sq ft</span>
          </div>
        </div>

        {/* Quality Selector */}
        <div className="mb-8">
          <label className="text-sm font-medium text-foreground mb-3 block">Construction Quality</label>
          <div className="grid grid-cols-3 gap-3">
            {[1, 2, 3].map((level) => (
              <button
                key={level}
                onClick={() => setQuality(level)}
                className={`p-4 rounded-xl border-2 transition-all ${
                  quality === level
                    ? "border-primary bg-primary/10 scale-105"
                    : "border-primary/20 hover:border-primary/30 hover:bg-primary/5"
                }`}
              >
                <div className={`font-bold mb-1 ${quality === level ? "text-primary" : "text-muted-foreground"}`}>
                  {qualityLabels[level - 1]}
                </div>
                <div className="text-sm text-muted-foreground">
                  ₹{level === 1 ? "1.2K" : level === 2 ? "1.8K" : "2.5K"}/sq ft
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Results */}
        <div className="space-y-4 mb-6">
          <div className="flex items-center justify-between p-4 rounded-xl bg-primary/10 border border-primary/20">
            <div className="flex items-center gap-3">
              <DollarSign className="w-5 h-5 text-primary" />
              <span className="font-medium">Total Cost</span>
            </div>
            <span className="text-2xl font-black text-primary">
              ₹{(totalCost / 100000).toFixed(2)}L
            </span>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="p-3 rounded-lg bg-card border border-primary/20 text-center">
              <div className="text-xs text-muted-foreground mb-1">Materials</div>
              <div className="font-bold text-foreground">₹{(materialCost / 100000).toFixed(2)}L</div>
            </div>
            <div className="p-3 rounded-lg bg-card border border-primary/20 text-center">
              <div className="text-xs text-muted-foreground mb-1">Labor</div>
              <div className="font-bold text-foreground">₹{(laborCost / 100000).toFixed(2)}L</div>
            </div>
            <div className="p-3 rounded-lg bg-card border border-primary/20 text-center">
              <div className="text-xs text-muted-foreground mb-1">Other</div>
              <div className="font-bold text-foreground">₹{(otherCost / 100000).toFixed(2)}L</div>
            </div>
          </div>
        </div>

        {/* Info Card */}
        <div className="flex items-start gap-3 p-4 rounded-lg bg-primary/5 border border-primary/20">
          <Zap className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
          <div className="text-sm text-muted-foreground">
            <span className="font-semibold text-foreground">Quick Estimate:</span> This calculator provides an instant ballpark figure. For detailed project planning, use our AI-powered generator below.
          </div>
        </div>
      </div>
    </Card>
  );
}
