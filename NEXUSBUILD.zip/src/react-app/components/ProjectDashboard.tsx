import { Card } from "@/react-app/components/ui/card";
import { Progress } from "@/react-app/components/ui/progress";
import { Clock, IndianRupee, AlertTriangle, CheckCircle2, TrendingUp, BarChart3, PieChart, Calendar, Package, Hammer, Shield } from "lucide-react";
import { PieChart as RechartPie, Pie, Cell, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend, LineChart, Line, CartesianGrid } from "recharts";

interface TimelinePhase {
  name: string;
  duration: string;
  progress: number;
  status: "completed" | "in-progress" | "pending";
  startWeek: number;
  endWeek: number;
}

interface CostItem {
  category: string;
  amount: number;
  percentage: number;
  color: string;
}

interface Risk {
  title: string;
  severity: "high" | "medium" | "low";
  description: string;
}

interface MaterialEstimate {
  material: string;
  quantity: string;
  unitCost: number;
  totalCost: number;
}

export function ProjectDashboard() {
  const timelinePhases: TimelinePhase[] = [
    { name: "Site Preparation", duration: "2 weeks", progress: 100, status: "completed", startWeek: 1, endWeek: 2 },
    { name: "Foundation Work", duration: "4 weeks", progress: 75, status: "in-progress", startWeek: 3, endWeek: 6 },
    { name: "Structure & Framework", duration: "8 weeks", progress: 0, status: "pending", startWeek: 7, endWeek: 14 },
    { name: "Roofing & Exterior", duration: "3 weeks", progress: 0, status: "pending", startWeek: 15, endWeek: 17 },
    { name: "Interior & Finishing", duration: "6 weeks", progress: 0, status: "pending", startWeek: 18, endWeek: 23 },
  ];

  const costBreakdown: CostItem[] = [
    { category: "Materials", amount: 4500000, percentage: 45, color: "#FF6A00" },
    { category: "Labor", amount: 2500000, percentage: 25, color: "#FFA940" },
    { category: "Equipment", amount: 1500000, percentage: 15, color: "#FFD591" },
    { category: "Permits & Legal", amount: 800000, percentage: 8, color: "#FFEDD5" },
    { category: "Contingency", amount: 700000, percentage: 7, color: "#FFF7ED" },
  ];

  const materialEstimates: MaterialEstimate[] = [
    { material: "Cement (bags)", quantity: "450", unitCost: 350, totalCost: 157500 },
    { material: "Steel (tons)", quantity: "12", unitCost: 65000, totalCost: 780000 },
    { material: "Bricks (1000s)", quantity: "85", unitCost: 6500, totalCost: 552500 },
    { material: "Sand (cubic ft)", quantity: "2500", unitCost: 45, totalCost: 112500 },
    { material: "Aggregate (cubic ft)", quantity: "2000", unitCost: 55, totalCost: 110000 },
  ];

  const weeklyProgress = [
    { week: "Week 1", planned: 4, actual: 5 },
    { week: "Week 2", planned: 8, actual: 8 },
    { week: "Week 3", planned: 12, actual: 11 },
    { week: "Week 4", planned: 16, actual: 15 },
    { week: "Week 5", planned: 20, actual: 18 },
    { week: "Week 6", planned: 24, actual: 22 },
  ];

  const totalBudget = costBreakdown.reduce((sum, item) => sum + item.amount, 0);

  const risks: Risk[] = [
    {
      title: "Weather Delays",
      severity: "medium",
      description: "Monsoon season approaching - may impact outdoor work phases"
    },
    {
      title: "Material Supply Chain",
      severity: "high",
      description: "Steel prices volatile - consider early procurement"
    },
    {
      title: "Permit Processing",
      severity: "low",
      description: "Minor delays possible in regulatory approvals"
    },
  ];

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high": return "text-red-500 bg-red-500/10 border-red-500/20";
      case "medium": return "text-yellow-500 bg-yellow-500/10 border-yellow-500/20";
      case "low": return "text-blue-500 bg-blue-500/10 border-blue-500/20";
      default: return "text-muted-foreground bg-muted/10 border-muted/20";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed": return <CheckCircle2 className="w-5 h-5 text-green-500" />;
      case "in-progress": return <TrendingUp className="w-5 h-5 text-primary" />;
      default: return <Clock className="w-5 h-5 text-muted-foreground" />;
    }
  };

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card border border-primary/20 p-3 rounded-lg shadow-lg">
          <p className="font-semibold text-foreground">{payload[0].name}</p>
          <p className="text-primary font-bold">₹{(payload[0].value / 100000).toFixed(2)}L</p>
          <p className="text-sm text-muted-foreground">{payload[0].payload.percentage}%</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-8">
      {/* Key Metrics Overview */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card className="p-6 border-primary/20 bg-gradient-to-br from-primary/10 to-primary/5">
          <div className="flex items-center gap-3 mb-2">
            <Calendar className="w-5 h-5 text-primary" />
            <span className="text-sm text-muted-foreground">Total Duration</span>
          </div>
          <div className="text-3xl font-black text-foreground">23 Weeks</div>
          <p className="text-xs text-muted-foreground mt-1">~5.5 months</p>
        </Card>

        <Card className="p-6 border-primary/20 bg-gradient-to-br from-primary/10 to-primary/5">
          <div className="flex items-center gap-3 mb-2">
            <IndianRupee className="w-5 h-5 text-primary" />
            <span className="text-sm text-muted-foreground">Total Budget</span>
          </div>
          <div className="text-3xl font-black text-foreground">₹{(totalBudget / 100000).toFixed(1)}L</div>
          <p className="text-xs text-muted-foreground mt-1">1 Crore estimate</p>
        </Card>

        <Card className="p-6 border-primary/20 bg-gradient-to-br from-green-500/10 to-green-500/5">
          <div className="flex items-center gap-3 mb-2">
            <CheckCircle2 className="w-5 h-5 text-green-500" />
            <span className="text-sm text-muted-foreground">Completed</span>
          </div>
          <div className="text-3xl font-black text-foreground">35%</div>
          <p className="text-xs text-muted-foreground mt-1">On schedule</p>
        </Card>

        <Card className="p-6 border-primary/20 bg-gradient-to-br from-yellow-500/10 to-yellow-500/5">
          <div className="flex items-center gap-3 mb-2">
            <AlertTriangle className="w-5 h-5 text-yellow-500" />
            <span className="text-sm text-muted-foreground">Active Risks</span>
          </div>
          <div className="text-3xl font-black text-foreground">3</div>
          <p className="text-xs text-muted-foreground mt-1">1 high priority</p>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Cost Distribution Pie Chart */}
        <Card className="p-6 border-primary/20">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
              <PieChart className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="text-xl font-bold">Cost Distribution</h3>
              <p className="text-sm text-muted-foreground">Budget allocation by category</p>
            </div>
          </div>
          
          <ResponsiveContainer width="100%" height={300}>
            <RechartPie>
              <Pie
                data={costBreakdown}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={(entry: any) => `${entry.category}: ${entry.percentage}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="amount"
              >
                {costBreakdown.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
            </RechartPie>
          </ResponsiveContainer>
        </Card>

        {/* Weekly Progress Chart */}
        <Card className="p-6 border-primary/20">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="text-xl font-bold">Weekly Progress</h3>
              <p className="text-sm text-muted-foreground">Planned vs Actual completion</p>
            </div>
          </div>
          
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={weeklyProgress}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--primary) / 0.1)" />
              <XAxis dataKey="week" stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: "hsl(var(--card))", 
                  border: "1px solid hsl(var(--primary) / 0.2)",
                  borderRadius: "8px"
                }}
              />
              <Legend />
              <Line type="monotone" dataKey="planned" stroke="#FFD591" strokeWidth={2} dot={{ fill: "#FFD591" }} />
              <Line type="monotone" dataKey="actual" stroke="#FF6A00" strokeWidth={2} dot={{ fill: "#FF6A00" }} />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Timeline Section */}
      <div>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
            <Clock className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="text-2xl font-bold">Construction Timeline</h3>
            <p className="text-sm text-muted-foreground">Phase-wise project duration</p>
          </div>
        </div>

        <div className="grid gap-4">
          {timelinePhases.map((phase, index) => (
            <Card key={index} className="p-5 border-primary/20 hover:border-primary/30 transition-colors">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  {getStatusIcon(phase.status)}
                  <div>
                    <h4 className="font-semibold text-foreground">{phase.name}</h4>
                    <p className="text-sm text-muted-foreground">
                      {phase.duration} • Week {phase.startWeek}-{phase.endWeek}
                    </p>
                  </div>
                </div>
                <span className={`text-sm font-medium px-3 py-1 rounded-full ${
                  phase.status === "completed" ? "bg-green-500/10 text-green-500" :
                  phase.status === "in-progress" ? "bg-primary/10 text-primary" :
                  "bg-muted/10 text-muted-foreground"
                }`}>
                  {phase.progress}%
                </span>
              </div>
              <Progress value={phase.progress} className="h-2" />
            </Card>
          ))}
        </div>
      </div>

      {/* Material Estimates */}
      <div>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
            <Package className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="text-2xl font-bold">Material Estimates</h3>
            <p className="text-sm text-muted-foreground">Detailed material requirements and costs</p>
          </div>
        </div>

        <Card className="border-primary/20 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-primary/5 border-b border-primary/20">
                <tr>
                  <th className="text-left p-4 font-semibold text-foreground">Material</th>
                  <th className="text-right p-4 font-semibold text-foreground">Quantity</th>
                  <th className="text-right p-4 font-semibold text-foreground">Unit Cost</th>
                  <th className="text-right p-4 font-semibold text-foreground">Total Cost</th>
                </tr>
              </thead>
              <tbody>
                {materialEstimates.map((item, index) => (
                  <tr key={index} className="border-b border-primary/10 hover:bg-primary/5 transition-colors">
                    <td className="p-4 font-medium text-foreground">{item.material}</td>
                    <td className="p-4 text-right text-muted-foreground">{item.quantity}</td>
                    <td className="p-4 text-right text-muted-foreground">₹{item.unitCost.toLocaleString()}</td>
                    <td className="p-4 text-right font-bold text-primary">₹{item.totalCost.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-primary/10 border-t-2 border-primary/30">
                <tr>
                  <td colSpan={3} className="p-4 font-bold text-foreground">Total Material Cost</td>
                  <td className="p-4 text-right font-black text-primary text-lg">
                    ₹{materialEstimates.reduce((sum, item) => sum + item.totalCost, 0).toLocaleString()}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </Card>
      </div>

      {/* Cost Breakdown Section */}
      <div>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
            <IndianRupee className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="text-2xl font-bold">Cost Breakdown</h3>
            <p className="text-sm text-muted-foreground">Total Budget: ₹{(totalBudget / 100000).toFixed(2)} Lakhs</p>
          </div>
        </div>

        <div className="grid gap-4">
          {costBreakdown.map((item, index) => (
            <Card key={index} className="p-5 border-primary/20 hover:border-primary/30 transition-colors">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className={`w-3 h-3 rounded-full`} style={{ backgroundColor: item.color }} />
                  <span className="font-semibold text-foreground">{item.category}</span>
                </div>
                <div className="text-right">
                  <p className="font-bold text-foreground">₹{(item.amount / 100000).toFixed(2)}L</p>
                  <p className="text-sm text-muted-foreground">{item.percentage}%</p>
                </div>
              </div>
              <Progress value={item.percentage} className="h-2" />
            </Card>
          ))}
        </div>
      </div>

      {/* Risk Summary Section */}
      <div>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
            <AlertTriangle className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="text-2xl font-bold">Risk Summary</h3>
            <p className="text-sm text-muted-foreground">Potential project risks and mitigation</p>
          </div>
        </div>

        <div className="grid gap-4">
          {risks.map((risk, index) => (
            <Card key={index} className={`p-5 border ${getSeverityColor(risk.severity)}`}>
              <div className="flex items-start gap-4">
                <AlertTriangle className={`w-6 h-6 flex-shrink-0 ${
                  risk.severity === "high" ? "text-red-500" :
                  risk.severity === "medium" ? "text-yellow-500" :
                  "text-blue-500"
                }`} />
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold text-foreground">{risk.title}</h4>
                    <span className={`text-xs font-medium px-2.5 py-1 rounded-full uppercase ${
                      risk.severity === "high" ? "bg-red-500/10 text-red-500" :
                      risk.severity === "medium" ? "bg-yellow-500/10 text-yellow-500" :
                      "bg-blue-500/10 text-blue-500"
                    }`}>
                      {risk.severity}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground">{risk.description}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Construction Phase Insights */}
      <div>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
            <Hammer className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="text-2xl font-bold">Phase Insights</h3>
            <p className="text-sm text-muted-foreground">Key considerations for each construction phase</p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <Card className="p-5 border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
            <div className="flex items-center gap-3 mb-3">
              <Shield className="w-6 h-6 text-primary" />
              <h4 className="font-bold text-foreground">Quality Checkpoints</h4>
            </div>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">•</span>
                <span>Foundation soil testing before concrete pour</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">•</span>
                <span>Steel quality verification with test certificates</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">•</span>
                <span>Concrete strength testing at 7 and 28 days</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">•</span>
                <span>Waterproofing inspection before backfilling</span>
              </li>
            </ul>
          </Card>

          <Card className="p-5 border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
            <div className="flex items-center gap-3 mb-3">
              <TrendingUp className="w-6 h-6 text-primary" />
              <h4 className="font-bold text-foreground">Cost Optimization Tips</h4>
            </div>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">•</span>
                <span>Bulk procurement of materials for better pricing</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">•</span>
                <span>Schedule work to avoid monsoon-related delays</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">•</span>
                <span>Use local materials to reduce transportation costs</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">•</span>
                <span>Consider alternative materials with similar quality</span>
              </li>
            </ul>
          </Card>
        </div>
      </div>
    </div>
  );
}
