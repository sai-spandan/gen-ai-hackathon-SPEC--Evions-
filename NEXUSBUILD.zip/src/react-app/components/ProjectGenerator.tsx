import { useState } from "react";
import { Card } from "@/react-app/components/ui/card";
import { Button } from "@/react-app/components/ui/button";
import { Input } from "@/react-app/components/ui/input";
import { Label } from "@/react-app/components/ui/label";
import { Calendar, IndianRupee, Building2, Loader2 } from "lucide-react";

export function ProjectGenerator() {
  const [startDate, setStartDate] = useState("");
  const [budget, setBudget] = useState("");
  const [projectType, setProjectType] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerate = async () => {
    if (!startDate || !budget || !projectType) {
      alert("Please fill in all fields");
      return;
    }

    setIsGenerating(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsGenerating(false);
    
    // Scroll to dashboard
    document.getElementById('dashboard')?.scrollIntoView({ behavior: 'smooth' });
  };

  const projectTypes = [
    { value: "residential", label: "Residential", icon: "🏠" },
    { value: "commercial", label: "Commercial", icon: "🏢" },
    { value: "infrastructure", label: "Infrastructure", icon: "🌉" },
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="p-8 md:p-12 border-primary/20 bg-card/80 backdrop-blur-sm">
        <div className="space-y-8">
          {/* Start Date */}
          <div className="space-y-3">
            <Label htmlFor="start-date" className="text-base font-semibold flex items-center gap-2">
              <Calendar className="w-5 h-5 text-primary" />
              Project Start Date
            </Label>
            <Input
              id="start-date"
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="h-12 border-primary/20 focus:border-primary bg-background/50"
            />
          </div>

          {/* Budget */}
          <div className="space-y-3">
            <Label htmlFor="budget" className="text-base font-semibold flex items-center gap-2">
              <IndianRupee className="w-5 h-5 text-primary" />
              Estimated Budget (₹ INR)
            </Label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground">₹</span>
              <Input
                id="budget"
                type="number"
                placeholder="10,00,000"
                value={budget}
                onChange={(e) => setBudget(e.target.value)}
                className="h-12 pl-8 border-primary/20 focus:border-primary bg-background/50"
              />
            </div>
          </div>

          {/* Project Type */}
          <div className="space-y-3">
            <Label className="text-base font-semibold flex items-center gap-2">
              <Building2 className="w-5 h-5 text-primary" />
              Project Type
            </Label>
            <div className="grid md:grid-cols-3 gap-4">
              {projectTypes.map((type) => (
                <button
                  key={type.value}
                  onClick={() => setProjectType(type.value)}
                  className={`p-4 rounded-lg border-2 transition-all hover:scale-105 ${
                    projectType === type.value
                      ? "border-primary bg-primary/10"
                      : "border-primary/20 bg-background/50 hover:border-primary/40"
                  }`}
                >
                  <div className="text-3xl mb-2">{type.icon}</div>
                  <div className="font-semibold">{type.label}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Generate Button */}
          <Button
            onClick={handleGenerate}
            disabled={isGenerating}
            className="w-full h-14 text-lg font-semibold glow-orange hover:glow-orange-strong transition-all"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Generating Project Plan...
              </>
            ) : (
              "Generate Project Plan"
            )}
          </Button>
        </div>
      </Card>
    </div>
  );
}
